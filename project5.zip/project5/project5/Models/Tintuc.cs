﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project5.Models
{
    public partial class Tintuc
    {
        public long Matt { get; set; }
        public string Tieude { get; set; }
        public string Noidung { get; set; }
        public DateTime? Ngaydang { get; set; }
        public string Img1 { get; set; }
        public string Img2 { get; set; }
        public string Img3 { get; set; }
        public string Tag { get; set; }
        public long? Maloaitt { get; set; }
    }
}
