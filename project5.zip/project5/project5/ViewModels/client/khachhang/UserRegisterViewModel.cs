﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project5.ViewModels.client.khachhang
{
    public class UserRegisterViewModel
    {
        public string Tendangnhap { get; set; }
        public string Hoten { get; set; }
        public string Diachi { get; set; }
        public string Email { get; set; }
        public string Dienthoai { get; set; }
        public string Password { get; set; }
    }
}
