﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project5.ViewModels.client.khachhang
{
    public class UserLoginViewModel
    {
        public string Tendangnhap { get; set; }
        public string Password { get; set; }
    }
}
