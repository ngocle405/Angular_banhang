﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project5.ViewModels.client.Chitietdathang
{
    public class OrderDetailViewModel
    {
      
        public long Id { get; set; }
        public int? Giaban { get; set; }
        public int? Soluong { get; set; }
    }
}
