﻿//using Microsoft.EntityFrameworkCore;
//using project5.Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace project5.Services.Admin.Nhacungcap
//{
//    public class NhacungcapServiceAdmin:INhacungcapServiceAdmin
//    {
//        private readonly Project5_DBContext _project5DBContext;
//        public NhacungcapServiceAdmin(Project5_DBContext project5DBContext)
//        {
//            _project5DBContext = project5DBContext;
//        }
//        //public async Task<List<Nhacungcap>> GetAll()
//        //{
//        //    return await _project5DBContext.Nhacungcaps.ToListAsync();
//        //}
//    }
//}
